# Auth Demo
这是一个简单的使用Spring Boot，Spring Security和JWT做RESTful API的登陆鉴权Demo。

启动项目后，浏览器打开http://localhost:8080/swagger-ui.html查看接口。

项目启动前需要配置数据库，在数据库中创建名为auth的数据库。IDE需要安装lombok插件。
