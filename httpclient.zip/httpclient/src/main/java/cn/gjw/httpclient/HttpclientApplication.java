package cn.gjw.httpclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpclientApplication {

    public static void main(String[] args) {
        SpringApplication.run(HttpclientApplication.class, args);
    }

}
